package com.example.my_bmi_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
